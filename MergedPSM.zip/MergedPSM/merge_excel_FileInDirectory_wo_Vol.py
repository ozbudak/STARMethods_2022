# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 21:09:07 2018

@author: My
"""

import os,sys
import re
import xlrd
#import xlwt
import xlsxwriter

def main():

    filename = {}    
    fileInDir = os.listdir(".")    # list file in directory
    for fn in fileInDir:
        check = 0
        # Merge file only if "_LP" is in the filename, to avoid merging the file 4 times
        if "_LP_PSM" in fn and ".xlsx" in fn:
            filename['LP'] = fn
            filename['LA'] = re.sub("LP_PSM","LA_PSM",fn)
            filename['RP'] = re.sub("LP_PSM","RP_PSM",fn)
            filename['RA'] = re.sub("LP_PSM","RA_PSM",fn)
            outFile = re.sub("LP","merged_wo_Vol",fn)
                        
            ## Check if file exist
            for f in filename:
                if not os.path.exists(filename[f]):
                    print('Error: File does not exist: %s' %filename[f])
                    check = -1
            
            if check == -1:
                continue
                
            imageInfoDict = {}
            imageInfoDict['Posterior'] = {}
            imageInfoDict['Anterior'] = {}
            count = {}
            count['Posterior'] = 1
            count['Anterior'] = 1
            
            # Read all four input file
            for key in ['LP','RP','LA','RA']:
                # Open the input file        
                if key in ['LP','RP']:
                    infoType = 'Posterior'
                else:
                    infoType = 'Anterior'
            
                workbook = xlrd.open_workbook(filename[key],'r')
                worksheets = workbook.sheet_names()
            
                # Iterate over each worksheet in a workbook
                for worksheet_name in worksheets:
                    worksheet = workbook.sheet_by_name(worksheet_name)
                    file_len = worksheet.nrows
                
                # Put the data coming from the files to the dictionary, 
                # Skip first line !!!
                    for j in range(1, file_len):
                        row = list(worksheet.row(j))
                        imageInfoDict[infoType][count[infoType]] = row[0:6]    # Only take first 6 columns from sheet 
                        count[infoType] = count[infoType] + 1
        
                    break # force the for loop to run only once (read the first worksheet only)
        
                # Write file    
                #workbook = xlwt.Workbook(encoding="ascii")
                #worksheet = workbook.add_sheet("Sheet1")
                workbook = xlsxwriter.Workbook(outFile) ## To save .xlsx file
                worksheet = workbook.add_worksheet()
                
                # Write header
                header = ['3 ID','Cell Position X','Cell Position Y','Cell Position Z','her1','her7','1 ID','Cell Position X','Cell Position Y','Cell Position Z','her1','her7']
                for i in range(len(header)):    
                    worksheet.write(0,i,header[i])
                
                # Write info
                for j in range(1,count['Posterior']):
                    for k in range(6):
                        worksheet.write(j,k,imageInfoDict['Posterior'][j][k].value)
                    
                for j in range(1,count['Anterior']):
                    for k in range(6):
                        worksheet.write(j,k+6,imageInfoDict['Anterior'][j][k].value)
               
                #workbook.save(experiment_name + "_merged.xls")
                workbook.close()
    
main()
