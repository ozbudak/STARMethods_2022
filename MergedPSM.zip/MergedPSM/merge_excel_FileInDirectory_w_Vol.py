# -*- coding: utf-8 -*-
"""
Edited on Thu Feb 7 2018, 
    calculate density based on cell volume information

Created on Fri Jan  5 21:09:07 2018

@author: My
"""

import os,sys
import re
import xlrd
#import xlwt
import xlsxwriter

def main():

    bgInfo = {}
    filename = {}    
    fileInDir = os.listdir(".")    # list file in directory
    for fn in fileInDir:
        check = 0
        # Merge file only if "_LP" is in the filename, to avoid merging the file 4 times
        if "LP_PSM" in fn and ".xlsx" in fn:
            filename['LP'] = fn
            filename['LA'] = re.sub("LP_PSM","LA_PSM",fn)
            filename['RP'] = re.sub("LP_PSM","RP_PSM",fn)
            filename['RA'] = re.sub("LP_PSM","RA_PSM",fn)
            outFile = re.sub("LP","merged_w_Vol",fn)
                        
            ## Check if file exist
            for f in filename:
                if not os.path.exists(filename[f]):
                    print('Error: File does not exist: %s' %filename[f])
                    check = -1
            
            if check == -1:
                continue
                
            imageInfoDict = {}
            imageInfoDict['Posterior'] = {}
            imageInfoDict['Anterior'] = {}
            count = {}
            count['Posterior'] = 1
            count['Anterior'] = 1
            
            # Read all four input file
            for key in ['LP','RP','LA','RA']:
                # Open the input file        
                if key in ['LP','RP']:
                    infoType = 'Posterior'
                else:
                    infoType = 'Anterior'
            
                workbook = xlrd.open_workbook(filename[key],'r')
                worksheets = workbook.sheet_names()
            
                # Iterate over each worksheet in a workbook
                for worksheet_name in worksheets:
                    worksheet = workbook.sheet_by_name(worksheet_name)
                    file_len = worksheet.nrows
                
                # Put the data coming from the files to the dictionary, 
                # Skip first line !!!
                    for j in range(1, file_len):
                        row = list(worksheet.row(j))
                        imageInfoDict[infoType][count[infoType]] = row[0:7]    # Take first 7 columns from sheet (including cell volume info) 
                        count[infoType] = count[infoType] + 1
                        
                        if j==1 and infoType=='Anterior':
                            bgInfo[filename[key]] = row[8:]
        
                    break # force the for loop to run only once (read the first worksheet only)
        
                # Write file    
                #workbook = xlwt.Workbook(encoding="ascii")
                #worksheet = workbook.add_sheet("Sheet1")
                workbook = xlsxwriter.Workbook(outFile) ## To save .xlsx file
                worksheet = workbook.add_worksheet()
                
                # Write header
                header = ['3 ID','Cell Position X','Cell Position Y','Cell Position Z','her1Density(count/pL)','her7Density(count/pL)','1 ID','Cell Position X','Cell Position Y','Cell Position Z','her1Density(count/pL)','her7Density(count/pL)']
                for i in range(len(header)):    
                    worksheet.write(0,i,header[i])
                
                # Write info
                for j in range(1,count['Posterior']):
                    for k in range(4):
                        worksheet.write(j,k,imageInfoDict['Posterior'][j][k].value)
                    worksheet.write(j,4,(imageInfoDict['Posterior'][j][4].value/imageInfoDict['Posterior'][j][6].value)*250)
                    worksheet.write(j,5,(imageInfoDict['Posterior'][j][5].value/imageInfoDict['Posterior'][j][6].value)*250)
                for j in range(1,count['Anterior']):
                    for k in range(4):
                        worksheet.write(j,k+6,imageInfoDict['Anterior'][j][k].value)
                    worksheet.write(j,4+6,(imageInfoDict['Anterior'][j][4].value/imageInfoDict['Anterior'][j][6].value)*250)
                    worksheet.write(j,5+6,(imageInfoDict['Anterior'][j][5].value/imageInfoDict['Anterior'][j][6].value)*250)
               
                #workbook.save(experiment_name + "_merged.xls")
                workbook.close()
                
    bgFile = xlsxwriter.Workbook("bgSomiteCount.xlsx")
    worksheet = bgFile.add_worksheet()
    
    header = ['filename', 'meansomitefarred','meansomitered','somitevariancefarred','somitevariancered', 'VOL_meansomitefarred','VOL_meansomitered','VOL_somitevariancefarred','VOL_somitevariancered']
    for i in range(len(header)):
        worksheet.write(0,i,header[i])
    curR = 1
    
    for k in bgInfo.keys():
        worksheet.write(curR,0,k)
        for i in range(len(bgInfo[k])):
            worksheet.write(curR,i+1,bgInfo[k][i].value)
        curR = curR+1
    bgFile.close()
    
main()
