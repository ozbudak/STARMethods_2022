clear

MyFolderInfo = dir();
rng(0,'twister');

for k=3:size(MyFolderInfo,1)

str1=strsplit(MyFolderInfo(k).name,'.');
str2=strsplit(MyFolderInfo(k).name,'P.');
if length(str1)==2&&length(str2)==2
    if strcmp(str2(2),'xlsx')&&strcmp(str1(1),strcat(str2(1),'P'))    
[CellPositionX,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','A3:A3000');
[CellPositionY,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','B3:B3000');
[CellPositionZ,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','C3:C3000');
[CellVolume,~,~] = xlsread(MyFolderInfo(k).name,'Cell Volume','A3:A3000');
[Redorgreen,~,~] = xlsread(MyFolderInfo(k).name,'Cell Number Of Vesicles Ves-1','A3:A3000');
[Farred,~,~] = xlsread(MyFolderInfo(k).name,'Cell Number Of Vesicles Ves-2','A3:A3000');

A=horzcat([0:length(CellPositionX)-1]',CellPositionX,CellPositionY,CellPositionZ,Farred,Redorgreen,CellVolume);
B=num2cell(A);
T=cell2table(B,'VariableNames',{'ID' 'CellPositionX' 'CellPositionY' 'CellPositionZ' 'Farred' 'Redorgreen' 'CellVolume'});
filename=strcat(cell2mat(str1(1)),'_PSM','.xlsx');
writetable(T,filename)
    end
end
end