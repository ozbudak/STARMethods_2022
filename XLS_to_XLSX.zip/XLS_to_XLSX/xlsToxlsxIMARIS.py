# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 21:09:07 2018

@author: My
This script will copy all worksheet from a .xls file and save into .xlsx file
Warning: Only final value is copied to the new file,
	all format, font, equation etc. will lost after the conversion
"""

import os,sys
import glob
import re
import csv
import xlrd
import xlsxwriter

def main():
	filename = {}
	fileInDir = glob.glob('*.xls') # list file in directory

	for fn in fileInDir:
		fn_out = fn.replace(".xls",".xlsx")
		wb_read = xlrd.open_workbook(fn,'r')
		wb_out = xlsxwriter.Workbook(fn_out)
		worksheets = wb_read.sheet_names()
		print("Converting %s to %s"%(fn,fn_out))
	
		# Iterate over each worksheet in a workbook
		for worksheet_name in worksheets:
			ws_in = wb_read.sheet_by_name(worksheet_name)
			ws_out = wb_out.add_worksheet(worksheet_name)
				
			for i, row in enumerate(range(ws_in.nrows)):
				for j, col in enumerate(range(ws_in.ncols)):
					ws_out.write(i,j,ws_in.cell_value(i, j))

		wb_out.close()

main()

