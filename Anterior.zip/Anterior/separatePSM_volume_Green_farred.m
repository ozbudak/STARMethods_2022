clear

MyFolderInfo = dir();
rng(0,'twister');

for k=3:size(MyFolderInfo,1)

str1=strsplit(MyFolderInfo(k).name,'.');
str2=strsplit(MyFolderInfo(k).name,'A.');
if length(str1)==2&&length(str2)==2
    if strcmp(str2(2),'xlsx')&&strcmp(str1(1),strcat(str2(1),'A'))    
[CellPositionX,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','A3:A5000');
[CellPositionY,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','B3:B5000');
[CellPositionZ,~,~] = xlsread(MyFolderInfo(k).name,'Cell Position','C3:C5000');
[CellVolume,~,~] = xlsread(MyFolderInfo(k).name,'Cell Volume','A3:A2000');
[NumberOfRed,~,~] = xlsread(MyFolderInfo(k).name,'Cell Number Of Vesicles Ves-1','A3:A2000');
[NumberOfFarRed,~,~] = xlsread(MyFolderInfo(k).name,'Cell Number Of Vesicles Ves-2','A3:A2000');
[Sx,~,~] = xlsread(MyFolderInfo(k).name,'Somite','A2:A5');
[Sy,~,~] = xlsread(MyFolderInfo(k).name,'Somite','B2:B5');
N=length(CellPositionX);
slop=(Sy(1)-Sy(2))/(Sx(1)-Sx(2));%define fist somite bondary line
int=Sy(1)-slop*Sx(1);
        somiteX=[];
        somiteY=[];
        somiteN=[];
for n=1:N
    if CellPositionX(n)<(CellPositionY(n)-int)/slop
        somiteY=[somiteY,CellPositionY(n)];
        somiteX=[somiteX,CellPositionX(n)];
        somiteN=[somiteN,n];
    end
end
Edgecell=[];
EdgecellX=[];
EdgecellY=[];
for n=1:N
    if CellPositionX(n)<min(Sx)-30
       Edgecell=[Edgecell,n];
       EdgecellX=[EdgecellX,CellPositionX(n)];
       EdgecellY=[EdgecellY,CellPositionY(n)];
    end
end
        somiteRed=[];
        somitefarred=[];
        somiteRed_volume=[];
        somitefarred_volume=[];
for i=1:length(somiteN)
    if isempty(find(Edgecell==somiteN(i)))
    somiteRed=[somiteRed,NumberOfRed(somiteN(i))];    
    somitefarred=[somitefarred,NumberOfFarRed(somiteN(i))];
    somiteRed_volume=[somiteRed,NumberOfRed(somiteN(i))/(CellVolume(somiteN(i))/250)];
    somitefarred_volume=[somitefarred,NumberOfFarRed(somiteN(i))/(CellVolume(somiteN(i))/250)];
    end
end
meansomiteRed=mean(somiteRed);
meansomitefarred=mean(somitefarred);
somitevarianceRed=var(somiteRed);
somitevariancefarred=var(somitefarred);
meansomiteRed_volume=mean(somiteRed_volume);
meansomitefarred_volume=mean(somitefarred_volume);
somitevarianceRed_volume=var(somiteRed_volume);
somitevariancefarred_volume=var(somitefarred_volume);
G=vertcat([0:0],meansomitefarred,meansomiteRed,somitevariancefarred,somitevarianceRed,meansomitefarred_volume,meansomiteRed_volume,somitevariancefarred_volume,somitevarianceRed_volume);
G=num2cell(G');
T1=cell2table(G,'VariableNames',{'ID' 'meansomitefarred' 'meansomiteRed' 'somitevariancefarred' 'somitevarianceRed' 'meansomitefarred_volume' 'meansomiteRed_volume' 'somitevariancefarred_volume' 'somitevarianceRed_volume'}); %generate background CB YB VARCB VARYB for wildtype_analysis.py 
PSM=[];
PSMCellPositionX=[];
PSMCellPositionY=[];
PSMCellPositionZ=[];
PSMCellVolume=[];
PSMher7=[];
PSMher1=[];
for i=1:N
    if isempty(find(somiteN==i))&&isempty(find(Edgecell==i))
    PSMCellPositionX=[PSMCellPositionX,CellPositionX(i)];
    PSMCellPositionY=[PSMCellPositionY,CellPositionY(i)];
    PSMCellPositionZ=[PSMCellPositionZ,CellPositionY(i)];
    PSMCellVolume=[PSMCellVolume,CellVolume(i)];
    PSMher7=[PSMher7,NumberOfRed(i)]; % Save Red channel to Her7
    PSMher1=[PSMher1,NumberOfFarRed(i)]; % Save Farred channel to Her1

    end
end
h=figure;
filename=[cell2mat(str1(1)) '.jpg'];
plot(EdgecellX,EdgecellY,'b--o',somiteX,somiteY,'g',PSMCellPositionX,PSMCellPositionY,'c*');
saveas(h,filename);
A=vertcat([0:length(PSMCellPositionX)-1],PSMCellPositionX,PSMCellPositionY,PSMCellPositionZ,PSMher1,PSMher7,PSMCellVolume);
A=num2cell(A');
T2=cell2table(A,'VariableNames',{'ID' 'PSMCellPositionX' 'PSMCellPositionY' 'PSMCellPositionZ' 'PSMfarred' 'PSMRed' 'CellVolume'});
[T,T2,T1]=outerjoin(T2,T1);
filename=strcat(cell2mat(str1(1)),'_PSM','.xlsx');
writetable(T,filename)
    end
end
end